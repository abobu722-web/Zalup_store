# Zalup_store — мерч-магазин

## Перегляд
Відкрий `index.html` у браузері.

## Публікація безкоштовно на GitHub Pages
1. Створи або увійди в акаунт на https://github.com/
2. Створи новий репозиторій, наприклад `film-merch-store`.
3. Завантаж `index.html` у корінь репозиторію (Add file → Upload files → Commit changes).
4. Відкрий Settings → Pages.
5. У розділі Build and deployment вибери Deploy from a branch, branch `main`, folder `/(root)`, натисни Save.
6. Після публікації GitHub покаже адресу на кшталт `https://username.github.io/film-merch-store/`.

## Перед запуском
Кошик працює в браузері, а оформлене замовлення надсилається на пошту магазину через FormSubmit (formsubmit.co). Оплата на сайті не приймається — її узгоджують із покупцем у Telegram.
